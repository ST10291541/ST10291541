/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice.task.pkg1;

import java.util.Scanner;

/**
 *
 * @author elishastephen
 */


 class Animal {
    protected int IDtag;
    protected String species;

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter IDtag: ");
        IDtag = scanner.nextInt();
        System.out.print("Enter species: ");
        species = scanner.next();
    }

    public void output() {
        System.out.println("IDtag: " + IDtag);
        System.out.println("Species: " + species);
    }
}

class Bird extends Animal {
    private int colour;

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feather colour (1=grey, 2=white, 3=black): ");
        colour = scanner.nextInt();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Feather Colour: " + getFeatherColour());
    }

    public String getFeatherColour() {
        switch (colour) {
            case 1:
                return "grey";
            case 2:
                return "white";
            case 3:
                return "black";
            default:
                return "unknown";
        }
    }
}

class Reptile extends Animal {
    private double bloodTemp;

    @Override
    public void input() {
        super.input();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter blood temperature: ");
        bloodTemp = scanner.nextDouble();
    }

    @Override
    public void output() {
        super.output();
        System.out.println("Blood Temperature: " + bloodTemp);
    }
}
public class IceTask1 {

    public static void main(String[] args) {
        Bird brd = new Bird();
        Reptile rept = new Reptile();

        System.out.println("Enter Bird Information:");
        brd.input();

        System.out.println("\nEnter Reptile Information:");
        rept.input();

        System.out.println("\nBird Information:");
        brd.output();

        System.out.println("\nReptile Information:");
        rept.output();
    }

}
